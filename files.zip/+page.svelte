<script>
  import LoginForm from '$lib/components/LoginForm.svelte';
</script>

<svelte:head>
  <title>Login — Welcome Back</title>
</svelte:head>

<main class="min-h-screen w-full flex items-center justify-center bg-white px-4">
  <div class="w-full max-w-sm animate-fade-in">
    <LoginForm />
  </div>
</main>

<style>
  @keyframes fade-in {
    from {
      opacity: 0;
      transform: translateY(16px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .animate-fade-in {
    animation: fade-in 0.5s ease-out both;
  }
</style>
