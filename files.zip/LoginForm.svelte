<script>
  import Input from '$lib/components/ui/Input.svelte';
  import Button from '$lib/components/ui/Button.svelte';

  let email = '';
  let password = '';
  let loading = false;
  let errors = { email: '', password: '' };

  function validate() {
    errors = { email: '', password: '' };
    let valid = true;

    if (!email.trim()) {
      errors.email = 'Email or username is required.';
      valid = false;
    }
    if (!password) {
      errors.password = 'Password is required.';
      valid = false;
    } else if (password.length < 6) {
      errors.password = 'Password must be at least 6 characters.';
      valid = false;
    }
    return valid;
  }

  async function handleLogin() {
    if (!validate()) return;
    loading = true;
    // Simulate API call
    await new Promise((r) => setTimeout(r, 1500));
    loading = false;
    alert(`Logged in as: ${email}`);
  }
</script>

<div class="w-full max-w-sm mx-auto flex flex-col gap-6">
  <!-- Title -->
  <div class="text-center">
    <h1 class="text-2xl font-bold text-[#0d0f1e] tracking-tight">Welcome Back</h1>
  </div>

  <!-- Fields -->
  <div class="flex flex-col gap-3">
    <Input
      id="email"
      name="email"
      type="email"
      placeholder="Enter email or username"
      bind:value={email}
      error={errors.email}
      autocomplete="email"
      required
    />

    <Input
      id="password"
      name="password"
      type="password"
      placeholder="Password"
      bind:value={password}
      error={errors.password}
      autocomplete="current-password"
      required
    />
  </div>

  <!-- Login Button -->
  <Button
    type="button"
    variant="primary"
    fullWidth
    {loading}
    on:click={handleLogin}
  >
    Login
  </Button>

  <!-- Terms -->
  <p class="text-center text-xs text-gray-500 leading-relaxed">
    By continuing, you agree to our
    <a href="/terms" class="underline underline-offset-2 hover:text-[#0d0f1e] transition-colors">Term</a>
    and
    <a href="/privacy" class="underline underline-offset-2 hover:text-[#0d0f1e] transition-colors">Privacy Policy</a>
  </p>

  <!-- Sign up link -->
  <p class="text-center text-sm text-gray-500">
    Don't have an account?
    <a href="/signup" class="text-[#0d0f1e] font-semibold underline underline-offset-2 hover:opacity-70 transition-opacity ml-1">
      Sign up
    </a>
  </p>
</div>
