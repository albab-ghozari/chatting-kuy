# Login Page — SvelteKit + Tailwind

Struktur komponen yang modular dan reusable, sesuai desain referensi.

---

## 📁 Struktur File

```
src/
├── lib/
│   └── components/
│       ├── index.js              ← Barrel export semua komponen
│       ├── LoginForm.svelte      ← Komponen form login utama
│       └── ui/
│           ├── Button.svelte     ← Tombol reusable
│           └── Input.svelte      ← Input field reusable
└── routes/
    └── +page.svelte              ← Halaman login
```

---

## 🧩 Komponen

### `Button.svelte`
Tombol serbaguna dengan variant dan ukuran yang bisa dikustomisasi.

**Props:**
| Prop | Type | Default | Deskripsi |
|------|------|---------|-----------|
| `type` | string | `'button'` | HTML button type |
| `variant` | `'primary'` \| `'secondary'` \| `'ghost'` | `'primary'` | Gaya tampilan |
| `size` | `'sm'` \| `'md'` \| `'lg'` | `'md'` | Ukuran tombol |
| `disabled` | boolean | `false` | Nonaktifkan tombol |
| `loading` | boolean | `false` | Tampilkan spinner loading |
| `fullWidth` | boolean | `false` | Lebar penuh container |

**Contoh penggunaan:**
```svelte
<Button variant="primary" fullWidth loading={isLoading} on:click={handleSubmit}>
  Login
</Button>

<Button variant="secondary" size="sm">
  Cancel
</Button>
```

---

### `Input.svelte`
Input field dengan label, error state, dan toggle password bawaan.

**Props:**
| Prop | Type | Default | Deskripsi |
|------|------|---------|-----------|
| `type` | string | `'text'` | HTML input type (`text`, `email`, `password`, dll) |
| `placeholder` | string | `''` | Placeholder teks |
| `value` | string | `''` | Nilai input (bindable) |
| `label` | string | `''` | Label di atas input |
| `id` | string | `''` | HTML id |
| `name` | string | `''` | HTML name |
| `error` | string | `''` | Pesan error (kosong = tidak ada error) |
| `disabled` | boolean | `false` | Nonaktifkan input |
| `required` | boolean | `false` | Tandai wajib diisi |
| `autocomplete` | string | `''` | HTML autocomplete |

**Contoh penggunaan:**
```svelte
<Input
  id="email"
  type="email"
  placeholder="Enter your email"
  bind:value={email}
  error={errors.email}
  required
/>

<Input
  id="password"
  type="password"
  placeholder="Password"
  bind:value={password}
  error={errors.password}
/>
```

---

### `LoginForm.svelte`
Form login lengkap dengan validasi client-side. Gunakan komponen ini di halaman mana pun.

```svelte
<script>
  import { LoginForm } from '$lib/components';
</script>

<LoginForm />
```

---

## 🚀 Setup

### 1. Install dependencies
```bash
npm create svelte@latest my-app
cd my-app
npm install
npx svelte-add@latest tailwindcss
npm install
```

### 2. Salin file
Salin folder `src/` ke dalam proyek SvelteKit kamu.

### 3. Jalankan
```bash
npm run dev
```

---

## ✨ Fitur
- ✅ Form validasi client-side
- ✅ Toggle show/hide password
- ✅ Loading state pada tombol
- ✅ Error state pada input
- ✅ Animasi fade-in halaman
- ✅ Fully accessible (label, aria, focus ring)
- ✅ Komponen reusable & composable
